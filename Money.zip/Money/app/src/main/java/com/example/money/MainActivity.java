package com.example.money;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    int a,b;
    boolean chose=true;
    int temp1=0;
    int temp2=0;
    int vnd=1;
    int usd=23550;
    int eur=26274;
    int bath=730;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ArrayList<String> arr=new ArrayList<String>();
        arr.add("Vietnam-VND");
        arr.add("United State-USD");
        arr.add("Euro- EUR");
        arr.add("Thailand-BAHT");

        ArrayAdapter arrayAdapter=new ArrayAdapter(this,android.R.layout.simple_spinner_item,arr);

        final TextView txt1=(TextView) findViewById(R.id.txt1);
        final TextView txt2=(TextView) findViewById(R.id.txt2);
        Spinner spin1=(Spinner)findViewById(R.id.snp1);
        spin1.setAdapter(arrayAdapter);
        spin1.setOnItemSelectedListener(new OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                //a=position;
                switch (position){
                    case 0: a=vnd;break;
                    case 1: a=usd;break;
                    case 2: a=eur;break;
                    case 3: a=bath;break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        Spinner spin2=(Spinner)findViewById(R.id.sp2);
        spin2.setAdapter(arrayAdapter);
        spin2.setOnItemSelectedListener(new OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                //b=position;
                switch (position){
                    case 0: b=vnd;break;
                    case 1: b=usd;break;
                    case 2: b=eur;break;
                    case 3: b=bath;break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        txt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chose=true;
                //temp1=0;
            }
        });

        txt2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chose=false;
                //temp2=0;
            }
        });

        findViewById(R.id.btn0).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /*if(chose) {temp1=temp1*10+0;;txt1.setText(String.valueOf(temp1));}
                else  { temp2=temp2*10+0;txt2.setText(String.valueOf(temp2));}*/
                HT(0,chose,txt1,txt2);
            }
        });
        findViewById(R.id.btn1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HT(1,chose,txt1,txt2);
            }
        });
        findViewById(R.id.btn2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HT(2,chose,txt1,txt2);
            }
        });
        findViewById(R.id.btn3).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HT(3,chose,txt1,txt2);
            }
        });
        findViewById(R.id.btn4).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HT(4,chose,txt1,txt2);
            }
        });
        findViewById(R.id.btn5).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HT(5,chose,txt1,txt2);
            }
        });
        findViewById(R.id.btn6).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HT(6,chose,txt1,txt2);
            }
        });
        findViewById(R.id.btn7).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HT(7,chose,txt1,txt2);
            }
        });
        findViewById(R.id.btn8).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HT(8,chose,txt1,txt2);
            }
        });
        findViewById(R.id.btn9).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HT(9,chose,txt1,txt2);
            }
        });
        findViewById(R.id.btnBS).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(chose) {temp1=temp1/10;;txt1.setText(String.valueOf(temp1));}
                else  { temp2=temp2/10;txt2.setText(String.valueOf(temp2));}
            }
        });
        findViewById(R.id.btnCE).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(chose) {temp1=0;;txt1.setText(String.valueOf(temp1));}
                else  { temp2=0;txt2.setText(String.valueOf(temp2));}
            }
        });
        findViewById(R.id.btnC).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                temp1=0;txt1.setText(String.valueOf(temp1));
                temp2=0;txt2.setText(String.valueOf(temp2));
                chose=true;
            }
        });

    }

    private void HT(int i, boolean chose,TextView txt1,TextView txt2) {
        int result;
        if(chose){
            temp1=temp1*10+i;
            txt1.setText(String.valueOf(temp1));
            result=temp1*a/b;
            txt2.setText(String.valueOf(result));
        }else{
            temp2=temp2*10+i;
            txt2.setText(String.valueOf(temp2));
            result=temp2*b/a;
            txt1.setText(String.valueOf(result));
        }
    }

}
