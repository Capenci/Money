package com.example.baitapvenha;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.GridView;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    List<ContactModel> contacts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        contacts = new ArrayList<>();
        contacts.add(new ContactModel("IT4060- Lập trình mạng",R.drawable.thumb1, true,"main", "08::57 AM"));
        contacts.add(new ContactModel("IT4060- Lập trình mạng",R.drawable.thumb2, true,"main", "08::57 AM"));
        contacts.add(new ContactModel("IT4060- Lập trình mạng",R.drawable.thumb3, true,"main", "08::57 AM"));
        contacts.add(new ContactModel("IT4060- Lập trình mạng",R.drawable.thumb4, true,"main", "08::57 AM"));
        contacts.add(new ContactModel("Name 5", R.drawable.thumb5, false,"main", "08::57 AM"));
        contacts.add(new ContactModel("Name 6", R.drawable.thumb6, false,"main", "08::57 AM"));
        contacts.add(new ContactModel("Name 7", R.drawable.thumb7, false,"main", "08::57 AM"));
        contacts.add(new ContactModel("Name 8", R.drawable.thumb8, true,"main", "08::57 AM"));
        contacts.add(new ContactModel("Name 9", R.drawable.thumb9, false,"main", "08::57 AM"));
        contacts.add(new ContactModel("Name 10", R.drawable.thumb10, true,"main", "08::57 AM"));
        contacts.add(new ContactModel("Name 11", R.drawable.thumb11, false,"main", "08::57 AM"));
        contacts.add(new ContactModel("Name 12", R.drawable.thumb12, true,"main", "08::57 AM"));
        contacts.add(new ContactModel("Name 13", R.drawable.thumb13, false,"main", "08::57 AM"));
        contacts.add(new ContactModel("Name 14", R.drawable.thumb14, false,"main", "08::57 AM"));
        contacts.add(new ContactModel("Name 15", R.drawable.thumb15, true,"main", "08::57 AM"));

        ImageAdapter adapter = new ImageAdapter(contacts);
        ListView listView = findViewById(R.id.list_view);
        listView.setAdapter(adapter);
    }
}
